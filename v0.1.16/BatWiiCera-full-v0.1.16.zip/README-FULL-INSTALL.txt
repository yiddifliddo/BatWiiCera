BatWiiCera 0.1.16 - full install (theme + Plaza channel)
Author: yiddifliddo

Extract this zip onto the Batocera network share (\\BATOCERA\share) so that
its folders merge with the ones already there:

  themes/BatWiiCera/                       the theme
  roms/ports/Plaza.sh                      "Plaza" under Ports (installer, repairer, launcher)
  roms/plaza/Plaza.love, gamelist.xml      the Plaza client (the channel's single entry)
  system/configs/emulationstation/         es_systems_plaza.cfg - the Plaza channel
  system/scripts/                          batwiicera-plaza-presence.sh - "now playing" hook

Then reboot Batocera (or restart EmulationStation) and choose the theme under
Main Menu > UI Settings > Theme set. The Plaza channel is on the console grid.
Nothing has to be typed: the public BatWiiCera server is built in.
